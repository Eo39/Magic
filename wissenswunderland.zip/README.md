# 🧙‍♂️ WissenWunderland

Eine interaktive Lern-App für Kinder von 5–9 Jahren. Bildbasiert, vorgelesen, spielerisch.

## ✨ Funktionen

| Bereich | Beschreibung |
|---|---|
| 📖 **Geschichten** | Zauberer Wissaldo erzählt lehrreiche Abenteuer (Ägypten, Dinos, Vulkane …) |
| 🎯 **Quiz** | Bildquiz: Welches Tier ist das? 5 Leben, grün/rot Feedback |
| ✏️ **Zeichnen** | Schritt-für-Schritt SVG-Tutorials (Katze, Haus, Stern …) |

Alle Texte können per Knopfdruck vorgelesen werden (gTTS, Deutsch).

---

## 🚀 Deployment auf Streamlit Community Cloud

### 1. Repository auf GitHub erstellen

```bash
git init
git add .
git commit -m "Initial commit – WissenWunderland"
git remote add origin https://github.com/DEIN_USERNAME/wissenswunderland.git
git push -u origin main
```

### 2. Hugging Face API-Token holen

1. Gehe zu [huggingface.co/settings/tokens](https://huggingface.co/settings/tokens)
2. Erstelle einen neuen Token (Read-Zugriff reicht)
3. Kopiere ihn

### 3. App auf Streamlit Cloud deployen

1. Gehe zu [share.streamlit.io](https://share.streamlit.io)
2. Klicke **New app** → wähle dein GitHub-Repo
3. Main file: `app.py`
4. Unter **Advanced settings → Secrets** eintragen:

```toml
HF_TOKEN = "hf_dein_token_hier"
```

5. Klicke **Deploy** – fertig! 🎉

---

## 🛠️ Lokal starten

```bash
# Dependencies installieren
pip install -r requirements.txt

# Secrets anlegen
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
# → secrets.toml bearbeiten und HF_TOKEN eintragen

# App starten
streamlit run app.py
```

---

## 🤖 Verwendete KI-Modelle

| Aufgabe | Modell |
|---|---|
| Textgenerierung (Geschichten) | [Qwen/Qwen2.5-3B-Instruct](https://huggingface.co/Qwen/Qwen2.5-3B-Instruct) via HF Inference API |
| Sprachausgabe | [gTTS](https://pypi.org/project/gTTS/) (Google Text-to-Speech, kostenlos) |

> **Warum nicht XTTS-v2?**  
> XTTS-v2 ist ein sehr gutes Modell, benötigt aber ~2 GB RAM + GPU und kann nicht auf der kostenlosen Streamlit Community Cloud laufen. gTTS funktioniert ohne Hardware-Anforderungen und ist für Kinder-Apps gut genug. Wenn du einen eigenen Server mit GPU hast, kann `utils/tts.py` leicht auf XTTS-v2 umgestellt werden.

---

## 📁 Projektstruktur

```
wissenswunderland/
├── app.py                  # Hauptapp + Navigation
├── requirements.txt
├── .gitignore
├── .streamlit/
│   ├── config.toml         # Theme-Einstellungen
│   └── secrets.toml.example
├── pages/
│   ├── story.py            # 📖 Geschichten-Seite
│   ├── quiz.py             # 🎯 Quiz-Seite
│   └── draw.py             # ✏️ Zeichnen-Seite
└── utils/
    ├── llm.py              # Qwen2.5 via HF Inference API
    └── tts.py              # gTTS Sprachausgabe
```

---

## 🧩 Erweiterungsideen

- Weitere Tiere und Quiz-Kategorien (Fahrzeuge, Farben, Zahlen)
- Mehr Zeichentutorials (Hund, Baum, Rakete …)
- Punkte-System mit lokalem Speicher
- Mehrsprachig (Englisch, Türkisch …)
- Zahlen- und Buchstaben-Lernspiele

---

## 📄 Lizenz

MIT – frei verwendbar für Bildungszwecke.
